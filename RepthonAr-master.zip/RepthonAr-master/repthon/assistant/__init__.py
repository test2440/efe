from repthon import BOTLOG, BOTLOG_CHATID, zq_lo

from ..Config import Config
from ..core.inlinebot import *
