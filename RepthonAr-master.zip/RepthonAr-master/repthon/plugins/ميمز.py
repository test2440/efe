import asyncio
import random
from asyncio.exceptions import TimeoutError

from telethon import events

from repthon.utils import admin_cmd
from repthon import zq_lo
from ..helpers.utils import reply_id

# الي يخمط ويكول من كتابتي الا امه انيجه وقد اعذر من انذر


#السلام على الحسين وعلى الارواح التي حلت بفنائك ولعن الله قاتليك
@zq_lo.on(admin_cmd(outgoing=True, pattern="شهر الحسين$"))
async def repthon313(therepthon313):
  rl = random.randint(1,31)
  url = f"https://t.me/alhusseinl313l/{rl}"
  await therepthon313.client.send_file(therepthon313.chat_id,url,caption="⎉╎ عظم الله لنا ولكم الاجر بهذا المُصاب الجلل 🏴",parse_mode="html")
  await therepthon313.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="لاتغلط$"))
async def jepmeme(memejep):
  Rep = await reply_id(memerep)
  url = f"https://t.me/MemeSoundJep/4"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="بجيت$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/5"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="نشاقة$"))
async def jepmeme(memejep):
  Rep = await reply_id(memerep)
  url = f"https://t.me/MemeSoundJep/3"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="احب الله$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/2"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="روح$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/6"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي1$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/7"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي2$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/9"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي3$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/11"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي4$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/12"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي5$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/13"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي6$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/14"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي7$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/15"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي8$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/16"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي9$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/17"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انمي10$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/18"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="زيج2$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/19"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="زيج$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/20"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="(شيله عبود|شيلة عبود)"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/21"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="تخوني$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/26"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="احب العراق$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/27"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="مستمرة الكلاوات$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/28"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="احبك$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/29"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اخت التنيج$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/30"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اذا اكمشك$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/31"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اسكت$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/32"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="افتهمنا$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/33"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اكل خرا$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/34"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="الكعده وياكم"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/35"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="الكمر اني$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/36"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اللهم لا شماته$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/37"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اني مااكدر$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/38"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="بقولك ايه$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/39"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="تف على شرفك$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/40"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="شجلبت$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/41"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="شكد شفت ناس$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/42"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="صباح القنادر$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/43"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="ضحكة فيطية$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/44"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="طاهر القلب"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/45"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="غطيلي$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/46"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="في منتصف الجبهة$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/49"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="لاتقتل المتعه$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/50"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="لا لتغلط$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/51"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="لا يمه لا$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/52"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="لحد يحجي وياي$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/53"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="ماادري يعني$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/54"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="منو انت$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/55"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="مو صوجكم$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/56"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="خوش تسولف"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/57"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="يع$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/58"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="يعني مااعرف$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/59"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="يامرحبا$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/60"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="منو انتة$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/61"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="ماتستحي$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/62"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="عيب$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/63"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="عنعانم$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/64"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="طبك مرض$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/65"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="سييي$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/66"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="سبيدر مان"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/67"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="خاف حرام$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/68"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="تحيه لاختك$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/69"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="روح$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/71"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="امشي كحبة$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/72"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="امداك$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/73"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="الحس$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/74"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="افتهمنا$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/75"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اطلع برا$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/77"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اوني تشان"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/78"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اخت التنيج$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/79"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="اوني تشان2$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/97"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="كعدت الديوث$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/98"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="خبز يابس$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/100"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="خيار بصل$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/101"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="ماي ارو$"))
async def jepmeme(memejep):
  Rep = await reply_id(memejep)
  url = f"https://t.me/MemeSoundJep/102"
  await memejep.client.send_file(memejep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memejep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="ولك حشاش$"))
async def repmeme(memerep):
 Rep = await reply_id(memerep)
 url = f"https://t.me/Repthon_meme/3"
 await memerep.client.send_file(memerep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
 await memerep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="انت شرايود$"))
async def repmeme(memerep):
 Rep = await reply_id(memerep)
 url = f"https://t.me/Repthon_meme/16"
 await memerep.client.send_file(memerep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
 await memerep.delete()
@zq_lo.on(admin_cmd(outgoing=True, pattern="بالعباس$"))
async def repmeme(memerep):
  Rep = await reply_id(memerep)
  url = f"https://t.me/Repthon_meme/18"
  await memerep.client.send_file(memerep.chat_id,url,caption="",parse_mode="html",reply_to=Rep)
  await memerep.delete()
