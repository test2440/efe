__**To store cache file of Repthon**__
